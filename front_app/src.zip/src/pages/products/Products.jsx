import React, { useState, useEffect } from 'react';
import { useNavigate } from "react-router-dom";
import NavigationBar from '../../components/NavigationBar/NavigationBar';
import AddProductModal from '../../components/AddProductModal/AddProductModal';
import ProductCard from '../../components/AddProductModal/ProductCard';
import axios from 'axios';

const Products = ({ logout, onProfileClick }) => {
  const navigate = useNavigate();
  const [myProducts, setMyProducts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Carga los productos del usuario desde la API
  useEffect(() => {
    const fetchUserProducts = async () => {
      setIsLoading(true);
      setError(null);
      try {
        const userId = localStorage.getItem('userId');
        if (!userId) {
          navigate('/login');
          return;
        }
        
        // --- Petición a la API para obtener productos ---
        const response = await axios.get(`https://tu-api.com/api/products/user/${userId}`);
        
        setMyProducts(response.data.products || []);
        
      } catch (err) {
        console.error("Error al obtener productos:", err);
        setError("No se pudieron cargar tus productos.");
      } finally {
        setIsLoading(false);
      }
    };

    fetchUserProducts();
  }, [navigate]);

  // Maneja la creación de un nuevo producto
  const handleAddProduct = async (productData) => {
    try {
      const userId = localStorage.getItem('userId');
      const dataToSend = { ...productData, owner: userId, price: parseFloat(productData.price) };

      // --- Petición a la API para crear un producto ---
      const response = await axios.post('https://tu-api.com/api/products', dataToSend);
      
      setMyProducts(prev => [...prev, response.data]);
      setIsModalOpen(false);
      
    } catch (err) {
      alert("Error al guardar el producto.");
    }
  };

  return (
    <>
      <div className="bg-gray-100 min-h-screen">
        {/* 1. Renderiza la barra de navegación como en Profile.jsx */}
        <NavigationBar logout={logout} onProfileClick={onProfileClick} />

        {/* 2. Contenedor principal con el mismo estilo que Profile.jsx */}
        <div className="container mx-auto py-12 px-4">
          <div className="w-full p-8 space-y-6 bg-white rounded-lg shadow-md">
            
            {/* Header de la sección de productos */}
            <div className="flex justify-between items-center">
              <h1 className="text-2xl font-bold text-gray-800">
                Mis Productos
              </h1>
              <button
                onClick={() => setIsModalOpen(true)}
                className="px-4 py-2 font-bold text-white bg-green-600 rounded-lg hover:bg-green-700"
              >
                + Agregar Producto
              </button>
            </div>

            <hr />

            {/* Catálogo de productos */}
            <div className="space-y-3">
              <h2 className="text-lg font-semibold text-gray-700">Mi Catálogo</h2>
              
              {isLoading && <p className="text-gray-500">Cargando...</p>}
              {error && <p className="text-red-500">{error}</p>}

              {!isLoading && !error && (
                myProducts.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 pt-4">
                    {myProducts.map(product => (
                      <ProductCard key={product._id || product.id} product={product} />
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-500 pt-4">No tienes productos en tu catálogo. ¡Añade el primero!</p>
                )
              )}
            </div>
          </div>
        </div>
      </div>

      {/* El Modal para agregar productos sigue igual */}
      <AddProductModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)}
        onSubmit={handleAddProduct} 
      />
    </>
  );
};

export default Products;