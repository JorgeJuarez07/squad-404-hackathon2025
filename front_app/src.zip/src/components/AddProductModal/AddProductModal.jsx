// src/components/AddProductModal/AddProductModal.js

import React, { useState } from 'react';

const AddProductModal = ({ isOpen, onClose, onSubmit }) => {
  const initialState = {
    name: '',
    description: '',
    price: '',
    unit: '',
    imageUrl: '',
    deliveryOption: 'Envío a domicilio'
  };

  const [formData, setFormData] = useState(initialState);

  // Un solo manejador para todos los inputs del formulario
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
    setFormData(initialState); // Limpia el formulario después de enviar
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex justify-center items-center z-50">
      <div className="bg-gray-800 p-8 rounded-2xl shadow-lg relative text-white max-w-md w-full mx-4">
        <button onClick={onClose} className="absolute top-4 right-4 text-white hover:text-green-400 text-3xl leading-none">
            &times;
        </button>
        <h3 className="text-xl sm:text-3xl font-bold mb-6 text-center text-green-400">Nuevo Producto</h3>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="name" className="block font-semibold mb-2 text-sm">Nombre del Producto</label>
            <input type="text" id="name" name="name" value={formData.name} onChange={handleChange} required
                className="w-full px-4 py-3 rounded-lg bg-white/20 placeholder-white/70 focus:outline-none focus:ring-2 focus:ring-green-400 text-sm" />
          </div>
          <div>
            <label htmlFor="description" className="block font-semibold mb-2 text-sm">Descripción</label>
            <textarea id="description" name="description" value={formData.description} onChange={handleChange} required
                className="w-full px-4 py-3 rounded-lg bg-white/20 placeholder-white/70 focus:outline-none focus:ring-2 focus:ring-green-400 text-sm h-24"></textarea>
          </div>
          <div>
            <label htmlFor="price" className="block font-semibold mb-2 text-sm">Precio</label>
            <input type="number" id="price" name="price" value={formData.price} onChange={handleChange} required
                className="w-full px-4 py-3 rounded-lg bg-white/20 placeholder-white/70 focus:outline-none focus:ring-2 focus:ring-green-400 text-sm" step="0.01" min="0" />
          </div>
          <div>
            <label htmlFor="unit" className="block font-semibold mb-2 text-sm">Unidad (ej: kg, pieza)</label>
            <input type="text" id="unit" name="unit" value={formData.unit} onChange={handleChange} required
                className="w-full px-4 py-3 rounded-lg bg-white/20 placeholder-white/70 focus:outline-none focus:ring-2 focus:ring-green-400 text-sm" />
          </div>
          <div>
            <label htmlFor="imageUrl" className="block font-semibold mb-2 text-sm">URL de la imagen</label>
            <input type="url" id="imageUrl" name="imageUrl" value={formData.imageUrl} onChange={handleChange} required
                className="w-full px-4 py-3 rounded-lg bg-white/20 placeholder-white/70 focus:outline-none focus:ring-2 focus:ring-green-400 text-sm" />
          </div>
          <div>
            <label htmlFor="deliveryOption" className="block font-semibold mb-2 text-sm">Opción de entrega</label>
            <select id="deliveryOption" name="deliveryOption" value={formData.deliveryOption} onChange={handleChange} required
                className="w-full px-4 py-3 rounded-lg bg-white/20 focus:outline-none focus:ring-2 focus:ring-green-400 text-sm">
                <option className="bg-gray-700" value="Envío a domicilio">Envío a domicilio</option>
                <option className="bg-gray-700" value="Recoger en tienda">Recoger en tienda</option>
            </select>
          </div>
          
          <button type="submit" className="w-full bg-green-600 font-bold py-3 px-6 rounded-full shadow-lg hover:bg-green-700 transition duration-300">
              Guardar Producto
          </button>
        </form>
      </div>
    </div>
  );
};

export default AddProductModal;